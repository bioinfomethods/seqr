# Seqr RNA Plot

## Getting Started

```bash
tar -zxvf SeqrRNAPlot.tar.gz

cd SeqrRNAPlot

python -m http.server

# Open a web browser and navigate to http://localhost:8000
```
